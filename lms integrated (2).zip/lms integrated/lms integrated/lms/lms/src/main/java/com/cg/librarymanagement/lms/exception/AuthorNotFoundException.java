package com.cg.librarymanagement.lms.exception;

public class AuthorNotFoundException extends RuntimeException
{
	public AuthorNotFoundException(String msg) {
		super(msg);
	}

	private static final long serialVersionUID = 1L;

}
