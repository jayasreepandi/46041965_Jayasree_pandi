package com.cg.lab2;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TraineJpaRepository extends JpaRepository<Trainee, Integer> {
}
