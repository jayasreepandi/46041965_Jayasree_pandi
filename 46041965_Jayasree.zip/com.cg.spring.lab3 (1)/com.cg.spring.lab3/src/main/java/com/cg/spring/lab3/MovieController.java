package com.cg.spring.lab3;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MovieController {
	
	@Autowired
	MovieService movieService;
	
	@GetMapping("/Movies")
	public List<Movies> getAllMovies()
	{
		return movieService.getAllMovies();
	}
	
	@GetMapping("/Movies/{genre}")
	public List<Movies> getMoviesByGenre(@PathVariable("genre") String genre)
	{
		return movieService.getMoviesByGenre(genre);
	}
	
	@DeleteMapping("/Movies/{movieName}")
	public void deleteMovie(@PathVariable("movieName") String movieName)
	{
		movieService.deleteMovie(movieName);
	}
	
	@PostMapping("/Movies")
	public String insertMovie(@RequestBody Movies movie)
	{
		movieService.insertMovie(movie);
		return movie.getMovieName();
	}
	
	@PutMapping("/Movies")
	public Movies updateMovie(@RequestBody Movies movie)
	{
		return movieService.updateMovie(movie);
	}
}
