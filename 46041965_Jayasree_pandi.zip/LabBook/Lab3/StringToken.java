
import java.util.StringTokenizer;

public class StringToken {
	public static void main(String[] args) {
		String a = "1 2 3 4 5";
		StringTokenizer s= new StringTokenizer(a);
		int sum=0;
		for(int i=0; i<a.length(); i++) {
			if(s.hasMoreTokens()) {
				int x = Integer.parseInt(s.nextToken());
				System.out.println("Integer :" + x);
				sum = sum + x; 
			}
		}
		System.out.println("Sum :" + sum);
	}
}
