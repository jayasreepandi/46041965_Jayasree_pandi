public class AlterString{
	
	public static void main(String args[]) {
		StringHandlingExample converter=new StringHandlingExample();
		String result=converter.convertUsingArray("Java");
		System.out.println(result);
	}
	
   public String convertUsingArray(String input) {
    	char characters[]=input.toCharArray();
    	for(int index=0;index<characters.length;index++) {
    		 char ch =characters[index];	
    	      if(ch!='a' && ch !='e' && ch!='i' && ch!='o' && ch!='u') {
    	    	  if(ch=='z') {
    	    	   char next='b';
    	    	   characters[index]=next;
    	    	  }else {
    	    	  int currentCharCode=ch;
    	    	  int nextCharCode=currentCharCode+1;
    	    	  System.out.println("current char code="+currentCharCode +" charcter="+ch);
    	    	  char nextChar=(char)nextCharCode;
    	    	  characters[index]=nextChar;
    	    	  }
    	      }
    	}
    	String result=new String(characters);
    	return result;
    }
}