
public class NumberofCharacters{
	public static void countCharacters(String s) {
		int countWords = 0;
		int countLines = 0;
		int countChar = 0;
		char[] a = s.toCharArray();
		countChar = a.length;
		System.out.println("Number of Characters in String : " + countChar);
		String[] b = s.split(" ");
		countWords = b.length;
		System.out.println("Number of Words in String: " + countWords);
		String[] v = s.split("\n");
		countLines = v.length;
		System.out.println("Number of Lines in String : " + countLines);
	}
	public static void main(String[] args) {
		String s = new String("hello there how are you\nI am fine");
		countCharacters(s);
	}

}
