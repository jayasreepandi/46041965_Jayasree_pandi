public class PositiveString{
	public static boolean isPositive(String s) {
		for(int i=0; i<s.length(); i++) {
			for(int j = i + 1; j<s.length(); j++) {
				if(Character.valueOf(s.charAt(i)).compareTo(
						Character.valueOf(s.charAt(j)) ) > 0) {
					return false;
				}
			}
		}
		return true;
	}
	public static void main(String[] args) {
		System.out.println(isPositive("ANT"));
	}
}
