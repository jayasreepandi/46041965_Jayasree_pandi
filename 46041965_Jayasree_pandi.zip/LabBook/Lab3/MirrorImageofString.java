public class MirrorImageofString{
	public static String getImage(String s) {
		StringBuffer a = new StringBuffer(s);
		a.reverse();
		String f = s + "|" + a;
		return f;
	}
	public static void main(String[] args) {
		System.out.println(getImage("EARTH"));
	}
}
