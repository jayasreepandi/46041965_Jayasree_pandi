public class Number {
	public static int modifyNumber(int n) {
		String s = Integer.toString(n);
		char[] c = s.toCharArray();
		int len = c.length;
		String a = "";
		for(int i=0; i<len-1; i++) {
			a = a + Math.abs(Integer.parseInt(Character.toString(c[i]))
					- Integer.parseInt(Character.toString(c[i + 1])));
		}
		a = a + Integer.parseInt(Character.toString(c[len - 1]));
		int x = Integer.parseInt(a);
		return x;
	}
	public static void main(String[] args) {
		int a = modifyNumber(126);
		System.out.println(a);
	}
}
