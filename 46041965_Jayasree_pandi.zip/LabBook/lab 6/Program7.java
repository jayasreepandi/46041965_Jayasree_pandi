import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Reverse
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		Sorting s = new Sorting();
		int n = sc.nextInt();
		int[] a = new int[n];
		for(int i=0;i<n;i++)
		{
			a[i]= sc.nextInt();
		}
		System.out.println("The array is "+s.getSorted(a));
		sc.close();
	}
}
class Sorting
{
	public List<Integer> getSorted(int[] a)
	{
		List<Integer> list2 = new ArrayList<Integer>();
	      for(int n :a) {
	         list2.add(n);
	      }
	      Collections.reverse(list2);
	      Collections.sort(list2);
	      return list2;
	}
}