public class Ex8IncreasingNumber {

	public static void main(String[] args) 
	{
		int n=10;
		boolean increasing=checkNum(n);
		System.out.println("Result: "+increasing);
	}
	public static boolean checkNum(int num)
	{
		int a=num;
		int prev=a%10;
		a=a/10;
		while(a>0)
		{
			int c=a%10;
			if(c>prev)
			{
				return false;
			}
			prev=c;
			a=a/10;
		}
		return true;
	}

}
