package com.capg.Lab1;

public class Ex4Prime {
	static void prime(int n)
	{
		int i;
		for(int num=1;num<n;num++)
		{
			for(i=2;num%i!=0;i++)
			{
				if(i==num)
				{
					System.out.println(num);
				}
			}
		}
	}
		public static void main(String args[])
		{
			
			int n1=10;
			prime(n1);
		}
	}


