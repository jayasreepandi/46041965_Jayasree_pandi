package com.capg.Lab1;
public class Ex1SumOfCubes {
	public static void main(String args[])
	{
		int num=10,sum=0;

		while(num>0)
		{
			int n=num%10;
			int c=n*n*n;
			sum=sum+c;
			num=num/10;
		}
		System.out.println("Sum of cubes: "+sum);
	}

}
