package com.capg.Lab1;
public class Ex3Fibonacci {
	static void fibonacci(int num)
	{
		int n1=0,n2=1,n3=0,i;
		for(i=1;i<num;i++)
		{
			n3=n1+n2;
			n1=n2;
			n2=n3;
		}
		System.out.println(n3);
	}
	public static void main(String args[])
	{
	
		int num=10;

		fibonacci(num);
	}
}
