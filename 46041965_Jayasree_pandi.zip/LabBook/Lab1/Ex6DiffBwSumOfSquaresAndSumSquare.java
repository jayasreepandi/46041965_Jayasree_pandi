package com.capg.Lab1;

public class Ex6DiffBwSumOfSquaresAndSumSquare {
	public static void main(String args[])
	{
	        int n=10;
		System.out.println(calculateDifference(n));
	}
	public static int calculateDifference(int n)
	{
		int diff,sumSquares=0,sum=0,squareSum=0;
        for (int i = 1; i <= n; i++) 
        {
            sumSquares+=i*i;
            sum+=i;
        }
        squareSum=sum^2;
        System.out.println(sumSquares+" "+sum);
        diff=sumSquares-squareSum;
        return diff;
}
}
