
public class Ex7PowerOf2 {
	public static void main(String[] args)
	{
		int n=10;
		boolean p=checkNumber(n);
		System.out.println("Result: "+p);
		sc.close();
	}
	public static boolean checkNumber(int n1)
	{
		return(n1!=0) && ((n1&(n1-1))==0);
	}

}
