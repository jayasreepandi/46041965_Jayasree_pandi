package com.capg.Lab4;

abstract  public class Item 
{
	private int id;
	private String title;
	private	int noOfCopies;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getNoOfCopies() {
		return noOfCopies;
	}
	public void setNoOfCopies(int noOfCopies) {
		this.noOfCopies = noOfCopies;
	}
abstract public static class WrittenItem extends Item
{
	private String data;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
	
}
public class Book extends WrittenItem
{
	
}
public class JournalPaper extends WrittenItem
{
	private int yearPublished;
}
abstract public static class MediaItem extends Item
{
	private int runTime;

	public int getRunTime() {
		return runTime;
	}

	public void setRunTime(int runTime) {
		this.runTime = runTime;
	}
}
public class Video extends MediaItem
{
	private String director;
	private String genre;
	private int year;
}
public class CD extends MediaItem
{
	private String artist;
	private String genre;
}
	public static void main(String args[])
	{
		//Item item=new Item();
		//WrittenItem wi=new WrittenItem();
	}
}
