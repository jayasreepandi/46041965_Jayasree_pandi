public class Person {
	private String name;
	private float age;
	Person(String name,float age){
		this.name=name;
		this.age=age;
	
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	
}
import java.util.Random;

public class Account {
	Random rand=new Random();
	private long accNum;
	private double balance;
	private Person accHolder;
	
	Account(){
		
	}
	
	Account(String name,float age,double balance){
		setAccHolder(new Person(name,age));
		this.balance=balance;
	}
	
	public void deposit(double depAmount) {
		balance=balance+depAmount;
		
	}
     public void withdraw(double withdrawAmt) {
		balance=balance-withdrawAmt;
	}
	
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

}
public class AccountMain {
	Account customers[]=new Account[2];
	public static void main(String[] args) {
		Account acc1=new Account("Smith",25,2000);
		Account acc2=new Account("Kalthy",23,3000);
		acc1.deposit(2000);
		acc2.withdraw(2000);
		System.out.println("Updated balance in Smith Account "+acc1.getBalance());
		System.out.println("Updated balance in Smith Account "+acc2.getBalance());
		 System.out.println();
		 
		Account acc3=new SavingAccount("Smith",25,2000);
		Account acc4=new SavingAccount("Kalthy",23,3000);
		acc3.deposit(2000);
		acc4.withdraw(3000);
		System.out.println("Updated balance in Smith Account "+acc3.getBalance());
		System.out.println("Updated balance in Smith Account "+acc4.getBalance());
		 System.out.println();
		
		Account acc5=new CurrentAccount("Smith",25,2000);
		Account acc6=new CurrentAccount("Kalthy",23,3000);
		acc5.deposit(3000);
		acc6.withdraw(4000);
		System.out.println("Updated balance in Smith Account "+acc5.getBalance());
		System.out.println("Updated balance in Smith Account "+acc6.getBalance());
		 System.out.println();
		
	}
}
import java.util.*;

public class CurrentAccount extends Account{
	void Account(){
	}
	Random rand=new Random();
	private double overdraftLimit=-500;
	@Override
	public void withdraw(double withdrawAmt) {
		double balance=getBalance();
		double temp=balance-withdrawAmt;
		if(temp>overdraftLimit) {
			System.out.println("True");
		}
			else
		{
			System.out.println("False");
		}
	}
	public CurrentAccount(String name,float age,double balance) {
		setAccHolder(new Person(name,age));
		setAccNum(rand.nextLong());
		setBalance(balance);
	}
	
}

public class CurrentAccount extends Account{
	void Account(){
	}
	Random rand=new Random();
	private double overdraftLimit=-500;
	@Override
	public void withdraw(double withdrawAmt) {
		double balance=getBalance();
		double temp=balance-withdrawAmt;
		if(temp>overdraftLimit) {
			System.out.println("True");
		}
			else
		{
			System.out.println("False");
		}
	}
	public CurrentAccount(String name,float age,double balance) {
		setAccHolder(new Person(name,age));
		setAccNum(rand.nextLong());
		setBalance(balance);
	}
	
}







