package com.cap.Lab2;

public class Ex1SecondSmallest {
public static int getSecondSmallest(int a[])
{
	int temp=0;
	 for (int i = 0; i < a.length; i++) {     
         for (int j = i+1; j < a.length; j++) {     
            if(a[i] > a[j]) 
            {    
                temp = a[i];    
                a[i] = a[j];    
                a[j] = temp;
            }     
         }
         
     }
	 System.out.println("the second smallest element is: "+a[1]);
	return 0;
}
public static void main(String args[])
{
	
	@SuppressWarnings("resource")
	int[] a ={3,5,7,1,8};
	getSecondSmallest(a);
}
}
