package com.cap.Lab2;

import java.util.Arrays;

public class Ex3ReverseAndSort {
	public static int getSorted(int a[])
	{
		int b[]=new int[a.length];
		int j=a.length;
		for (int i = 0; i < b.length; i++)
		{ 
            b[j - 1] = a[i]; 
            j= j - 1; 
        } 
		System.out.println("The reverse array is:");
		for(int k=0;k<a.length;k++)
		{
			System.out.print(b[k]+" ");
		}
		Arrays.sort(a);
		System.out.println("\n");
		System.out.println("final array:");
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
			
		return 0;
	}
	public static void main(String args[])
	{
		
		@SuppressWarnings("resource")
		
		int a[]={21,48,72,11,98};
		    getSorted(a);
	}

}
