package com.cap.Lab2;
import java.util.*;
import java.util.Arrays;
import java.lang.*;
@SuppressWarnings("unused")
public class Ex2SortStrings {
	public static String sortStrings(String[] a)
	{
		//char tempArray[] = a.toCharArray();  
		int j = 0;
	      char temp = 0;
	      char[] chars = a.toCharArray();
	      for(int i=0; i < chars.length; i++) {
	         for(j=0; j < chars.length; j++) {
	            if(chars[j] > chars[i]) {
	               temp = chars[i];
	               chars[i] = chars[j];
	               chars[j] = temp;
	            }
	         }
	      }
		return null;
	}

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		int n;
		System.out.println("Enter the size of string:");
		n=sc.nextInt();
		String[] a=new String[n];
		System.out.println("Enter string:");
		for(int j = 0; j < a.length;j++) 
	    {
			
	        a[j] = sc.nextLine();
	    }
		sortStrings(a);

	}

}
