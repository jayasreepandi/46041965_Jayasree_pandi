package com.cap.Lab2;
import java.util.Collections;
import java.util.Arrays;

public class Ex4DuplicateDesc
{
	public static int modifyArray(Integer a[])
	{
		int j=0;
		int b=a.length;
		if (b==0 || b==1) 
		{
	        return b; 
		}
		for(int i=0;i<b-1;i++)
		{
			if(a[i]!=a[i+1]);
			{
				a[j++]=a[i];
			}
		}
		a[j++]=a[b-1];
		for(int i=0;i<b;i++)
		{
			System.out.println(a[i]);
		}
		Arrays.sort(a, Collections.reverseOrder()); 
		  
        System.out.printf("Modified array is : %s", 
                          Arrays.toString(a));
		return 0; 
		
		
	}

	public static void main(String[] args)
	{
		
		Integer a[]=new Integer[n];
	
		int a[]={6,9,21,98};
		
		modifyArray(a);
		

	}

}
