package com.capg.Lab5;


@SuppressWarnings("serial")
class FullNameException extends Exception
{
	FullNameException(String msg)
	{
		System.out.println(msg);
	}
}
public class FullName 
{
	public static void main(String args[])
	{
		@SuppressWarnings("resource")
		String fn="Jahnavi";
		String ln="Lukka";
		try
		{
			if(fn.isEmpty()&& ln.isEmpty())
			{
				throw new FullNameException("No firstName And Lastname");
			}
			else
			{
				System.out.println(fn+" "+ln+" is a Valid Name");
			}
				
		}
		catch(FullNameException e)
		{
			System.out.println(e);
		}
	}

}
