package com.cg.eis.exception;
import java.util.Scanner;
public class EmployeeException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner sc=new Scanner(System.in);
      int salary=sc.nextInt();
      try
      {
    	  if(salary<3000) 
    	  {
    		  throw new MyException("salary must be greater then 3000");
      }
      }
      catch(MyException e)
      {
    	  System.out.println(e);
      }
      
	}
	}
	class MyException extends Exception
	{
		public MyException(String msg)
		{
			super(msg);
		}
	}