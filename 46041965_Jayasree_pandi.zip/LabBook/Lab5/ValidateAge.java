package com.capg.Lab5;
class AgeNotSupportException extends Exception
{
	AgeNotSupportException(String msg)
	{
		System.out.println("Hello.... "+msg);
	}
}

public class ValidateAge {
	int age=4;
	public void checkAge() throws AgeNotSupportException
	{
		if(age<18)
		{
			throw new AgeNotSupportException("you are Not eligible for voting");
		}
		else
		{
			System.out.println("You are eligible for voting..");
		}
	}
	public static void main(String args[])
	{
		try
		{
		ValidateAge vd=new ValidateAge();
		vd.checkAge();
		}
		catch(Exception e)
		{
			System.out.println("I can...."+e);
		}
		
	}

}
